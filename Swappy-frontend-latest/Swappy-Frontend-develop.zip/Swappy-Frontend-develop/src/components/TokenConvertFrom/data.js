let data = [
	{
		tokenName: "EUR",
		conversionRate: 123,
	},
	{
		tokenName: "USD",
		conversionRate: 233,
	},
	{
		tokenName: "RSD",
		conversionRate: 543,
	},
	{
		tokenName: "EUR",
		conversionRate: 123,
	},
	{
		tokenName: "USD",
		conversionRate: 233,
	},
	{
		tokenName: "RSD",
		conversionRate: 543,
	},
];

export default data;
