import React from "react";
import { mount } from "enzyme";
import TokenConvertFrom from "./TokenConvertFrom";

describe("Unit tests for TokenConvertFrom component", () => {
	it("tests whether component mounts correctly", () => {
		mount(<TokenConvertFrom />);
	});
});
