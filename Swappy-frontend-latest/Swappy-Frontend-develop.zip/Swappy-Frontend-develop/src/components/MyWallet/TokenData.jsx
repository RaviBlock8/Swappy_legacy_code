const TokenData = [
	{
		tokenName: "BTC",
		amount: 223.32,
	},
	{
		tokenName: "DAI",
		amount: 321.32,
	},
	{
		tokenName: "ETH",
		amount: 400,
	},
	{
		tokenName: "TEK",
		amount: 113.32,
	},
	{
		tokenName: "ASC",
		amount: 2000,
	},
	{
		tokenName: "BSC",
		amount: 12.21,
	},
	{
		tokenName: "BTC",
		amount: 223.32,
	},
];

export default TokenData;
