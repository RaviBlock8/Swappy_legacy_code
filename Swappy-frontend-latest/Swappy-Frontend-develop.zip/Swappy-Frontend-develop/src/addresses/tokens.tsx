export interface TokenDataInterface {
	name: string;
	address: string;
}

export const data = [
	// {
	// 	name: "ETH",
	// 	address: "0x8f2b097e79b1c51be9cba42658862f0192c3e487",
	// },
	{
		name: "DAI",
		address: "0xc7AD46e0b8a400Bb3C915120d284AafbA8fc4735",
	},
	{
		name: "ASC",
		address: "0x5193fc7285ccc9c68442f2e33448ac0108676108",
	},
	{
		name: "BSC",
		address: "0x03ca8ddb9509d21286433d0cb29e61e35754c1ce",
	},
	{
		name: "TRX",
		address: "0x6867399898818428bc23B5adc82a94b13C48Bffb",
	},
	{
		name: "LXS",
		address: "0xa1788D749dD9203A88b7e02F761B099E030B78D6",
	},
	{
		name: "DXS",
		address: "0xF463598da3ed7EEd0fE6b6af23F0b40D44625e12",
	},
	{
		name: "BK8",
		address: "0xeE1b89d47173688BE8843bECC763f4dc7D1bbFc1",
	},
	{
		name: "RMX",
		address: "0x6afc520b63caC3D1bA4584E770df9acE3C47C049",
	}
	// {
	// 	name: "ABC",
	// 	address: "0x78e578a5b0D98F71320C0264F46DBbdea4907f08",
	// },
	// {
	// 	name: "DEF",
	// 	address: "0x0c84430F589959b498896c4A35Ea16f6a09C634B",
	// },
	// {
	// 	name: "LASC",
	// 	address: "0xfEd16d99D8A696df2216808BdF80d3976fa0Ab8e",
	// },
	// {
	// 	name: "LBSC",
	// 	address: "0x2754F5427FE6803c1437C16c0d69F05Db0b60816",
	// },
];
