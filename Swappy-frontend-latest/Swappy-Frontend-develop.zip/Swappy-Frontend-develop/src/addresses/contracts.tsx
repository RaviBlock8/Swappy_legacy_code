export interface IAddresses {
	router: string | undefined;
	factory: string | undefined;
}

export interface IHash {
	[details: string] : IAddresses;
}
export const Contracts: IHash = {
	"1": {
		router: "",
		factory: "",
	},
	"4": {
		factory: "0x8a24c0ef7dc8178ead4abef9c9997a6ad71f8b28",
		router: "0x3350898705f9F36d87Dd914b39e4E2858a74012f"
	},
	"5777": {
		factory: process.env.REACT_APP_FACTORY,
		router: process.env.REACT_APP_ROUTER
	}
}
